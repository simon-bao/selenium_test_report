package com.lxinet.jeesns.modules;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		List list=new ArrayList();
		list.add("1");
		list.add("1");
		list.add("1");
		list.add("1");
		list.add("1");
		list.add("1");
		long startTime=System.currentTimeMillis();
		for(int i=0;i<list.size();i++){
			list.get(5);
		}
		long endTime=System.currentTimeMillis();
		System.out.println(endTime-startTime);
		
		LinkedList l=new LinkedList();
		l.add("2");
		l.add("2");
		l.add("2");
		l.add("2");
		l.add("2");
		l.add("2");
		long startTime2=System.currentTimeMillis();
		for(int i=0;i<l.size();i++){
			l.get(5);
		}
		long endTime2=System.currentTimeMillis();
		System.out.println(endTime2-startTime2);
	}
}
