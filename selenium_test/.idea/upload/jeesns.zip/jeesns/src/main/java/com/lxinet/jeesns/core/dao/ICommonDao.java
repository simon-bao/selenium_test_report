package com.lxinet.jeesns.core.dao;


/**
 * Created by zchuanzhao on 2017/2/6.
 */
public interface ICommonDao extends IBaseDao {

    String getMysqlVsesion();
    
}