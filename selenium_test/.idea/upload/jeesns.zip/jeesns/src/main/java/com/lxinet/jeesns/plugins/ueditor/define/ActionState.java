package com.lxinet.jeesns.plugins.ueditor.define;

public enum ActionState {
	UNKNOW_ERROR
}
