package com.lxinet.jeesns.core.entity;

import java.io.Serializable;

/**
 * Created by zchuanzhao on 16/9/29.
 */
public class BaseEntity implements Serializable {

}
