package com.lxinet.jeesns.core.service;


/**
 * Created by zchuanzhao on 2017/2/6.
 */
public interface ICommonService {

    String getMysqlVsesion();
}
